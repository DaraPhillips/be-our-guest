export default function gallery(){
    return (

<div className='topyoke'>
<h3 className='home-tab-top-thingy'>Home / </h3> <h3 className='other-tab-at-top'>Gallery</h3>
</div>

    )
 }